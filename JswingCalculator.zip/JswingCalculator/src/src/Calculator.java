package src;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Calculator {

	//Global Variables
	private JFrame frmSimpleCalcualtor;
	private JTextField textDisplay;
	
	double firstnum, secondnum, result;
	String operations, answer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculator window = new Calculator();
					window.frmSimpleCalcualtor.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Calculator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSimpleCalcualtor = new JFrame();
		frmSimpleCalcualtor.setTitle("Calculator");
		frmSimpleCalcualtor.setBounds(100, 100, 293, 438);
		frmSimpleCalcualtor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSimpleCalcualtor.getContentPane().setLayout(null);
		
		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn7.getText();
				textDisplay.setText(EnterNumber);
			}
		});
		btn7.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn7.setBounds(12, 83, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn8.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn8.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn8.setBounds(74, 83, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn9.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn9.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn9.setBounds(136, 83, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn9);
		
		JButton btnPlus = new JButton("+");
		btnPlus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(textDisplay.getText());
				textDisplay.setText("");
				operations = "+";
			}
	});
		btnPlus.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnPlus.setBounds(198, 83, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btnPlus);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn4.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn4.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn4.setBounds(12, 146, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn5.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn5.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn5.setBounds(74, 146, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn6.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn6.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn6.setBounds(136, 146, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn6);
		
		JButton btnSub = new JButton("-");
		btnSub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(textDisplay.getText());
				textDisplay.setText("");
				operations = "-";
			}
	});
		btnSub.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnSub.setBounds(198, 146, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btnSub);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn1.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn1.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn1.setBounds(12, 206, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn2.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn2.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn2.setBounds(74, 209, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn3.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn3.setBounds(136, 209, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn3);
		
		JButton btnMulti = new JButton("*");
		btnMulti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(textDisplay.getText());
				textDisplay.setText("");
				operations = "*";
			}
	});
		btnMulti.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnMulti.setBounds(198, 206, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btnMulti);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btn0.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btn0.setFont(new Font("Tahoma", Font.BOLD, 18));
		btn0.setBounds(12, 269, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btn0);
		
		JButton btnEQ = new JButton("=");
		btnEQ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String answer;
				secondnum = Double.parseDouble(textDisplay.getText());
				if(operations == "+")
				{
					result = firstnum + secondnum;
					answer = String.format("%.2f",result);
					textDisplay.setText(answer);
				}
				else if	(operations == "-"){
					
					result = firstnum - secondnum;
					answer = String.format("%.2f",result);
					textDisplay.setText(answer);
					}
				
			    else if	(operations == "*"){
					
					result = firstnum * secondnum;
					answer = String.format("%.2f",result);
					textDisplay.setText(answer);
					}
				
			    else if	(operations == "/"){
					
					result = firstnum / secondnum;
					answer = String.format("%.2f",result);
					textDisplay.setText(answer);
					}
			}
	});
		btnEQ.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnEQ.setBounds(74, 332, 102, 50);
		frmSimpleCalcualtor.getContentPane().add(btnEQ);
		
		JButton btnDiv = new JButton("/");
		btnDiv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(textDisplay.getText());
				textDisplay.setText("");
				operations = "/";
			}
	});
		btnDiv.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDiv.setBounds(198, 269, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btnDiv);
		
		JButton btnDot = new JButton(".");
		btnDot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String EnterNumber = textDisplay.getText() + btnDot.getText();
				textDisplay.setText(EnterNumber);
			}
	});
		btnDot.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnDot.setBounds(74, 269, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btnDot);
		
		JButton btnClear = new JButton("C");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textDisplay.setText(null);
			}
	});
		
		btnClear.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnClear.setBounds(136, 269, 50, 50);
		frmSimpleCalcualtor.getContentPane().add(btnClear);
		
		textDisplay = new JTextField();
		textDisplay.setFont(new Font("Tahoma", Font.BOLD, 16));
		textDisplay.setHorizontalAlignment(SwingConstants.RIGHT);
		textDisplay.setBackground(Color.WHITE);
		textDisplay.setBounds(12, 23, 248, 43);
		frmSimpleCalcualtor.getContentPane().add(textDisplay);
		textDisplay.setColumns(10);
		
		JButton btnPS = new JButton("+-");
		btnPS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Double ops = Double.parseDouble(String.valueOf(textDisplay.getText()));
				ops = ops * (-1);
				textDisplay.setText(String.valueOf(ops));
				
			}
		});
		btnPS.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnPS.setBounds(188, 332, 60, 50);
		frmSimpleCalcualtor.getContentPane().add(btnPS);
		
	}
}
